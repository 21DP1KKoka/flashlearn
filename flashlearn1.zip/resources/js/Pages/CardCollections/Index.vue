<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import CardCollection from '@/Components/CardCollection.vue';
import InputError from '@/Components/InputError.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import { useForm, Head } from '@inertiajs/vue3';
 

defineProps(['cardCollections'])

const form = useForm({
    name: '',
});

</script>
 
<template>
    <Head title="CardCollections" />
 
    <AuthenticatedLayout>
        <div class="max-w-2xl mx-auto p-4 sm:p-6 lg:p-8">
            <form @submit.prevent="form.post(route('cardCollections.store'), { onSuccess: () => form.reset() })">
                <textarea
                    v-model="form.name"
                    placeholder="Ieraksti kartīšu kolekcijas nosaukumu!"
                    class="block w-full border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm"
                ></textarea>
                <InputError :name="form.errors.name" class="mt-2" />
                <PrimaryButton class="mt-4">Izveidot kolekciju</PrimaryButton>
            </form>
            <div class="mt-6 bg-white shadows-sm rounded-lg divide-y">
                <CardCollection
                    v-for="cardCollection in cardCollections"
                    :key="cardCollection.id"
                    :cardCollection="cardCollection"
                />
            </div>
        </div>
    </AuthenticatedLayout>
</template>