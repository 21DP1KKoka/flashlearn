<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import CardCollection from '@/Components/CardCollection.vue';
import InputError from '@/Components/InputError.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import { useForm, Head } from '@inertiajs/vue3';
 

defineProps(['cards', 'cardCollections'])


const form = useForm({
    card_front: '',
    card_back: '',
    card_collection_id: '',
});

</script>
 
<template>
    <Head title="Cards" />
 
    <AuthenticatedLayout>
        <div class="max-w-2xl mx-auto p-4 sm:p-6 lg:p-8">

            

            <form @submit.prevent="form.post(route('cards.store'), { onSuccess: () => form.reset() })">
                <textarea
                    v-model="form.card_front"
                    placeholder="Ieraksti kartītes priekšpuses tekstu!"
                    class="block w-full border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm"
                ></textarea>
                <InputError :card_front="form.errors.card_front" class="mt-2" />

                <textarea
                    v-model="form.card_back"
                    placeholder="Ieraksti kartītes mugurpuses tekstu!"
                    class="block w-full border-gray-300 focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 rounded-md shadow-sm"
                ></textarea>
                <InputError :card_back="form.errors.card_back" class="mt-2" />

                <select v-model="form.card_collection_id">
                    <option v-for="cardCollection in cardCollections" :key="cardCollection.id" :value="cardCollection.id">
                        {{ cardCollection.name }}
                    </option>
                </select>
                <InputError :message="form.errors.card_collection_id" class="mt-2" />
                
                <PrimaryButton class="mt-4">Izveidot kolekciju</PrimaryButton>
            </form>
            
            <div class="mt-6 bg-white shadows-sm rounded-lg divide-y">
                <CardCollection
                    v-for="card in cards"
                    :key="card.id"
                    :card="card"
                />
            </div>
        </div>
    </AuthenticatedLayout>
</template>