<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphToMany;

class CardCollectionPermission extends Model
{
    use HasFactory;


    public function  user(): MorphToMany
    {
        return $this->morphToMany(User::class, 'Accessable');
    }


    public function cardCollection(): MorphToMany
    {
        return $this->morphToMany(CardCollection::class, 'Accessable');
    }


}
