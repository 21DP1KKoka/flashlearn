<?php

namespace App\Http\Controllers;


use App\Models\CardCollection;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;
use Inertia\Response;


class CardCollectionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(): Response
    {
        $user=Auth::user();
        $userid = $user->id;
        return Inertia::render('CardCollections/Index', [
            'cardCollections' => CardCollection::with('user:id,name')->where('user_id', $userid)->latest()->get(),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
        ]);

        $request->user()->cardCollections()->create($validated);

        return redirect(route('cardCollections.index'));
    }

    /**
     * Display the specified resource.
     */
    public function show(CardCollection $cardCollection)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(CardCollection $cardCollection)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, CardCollection $cardCollection): RedirectResponse
    {
        //
        Gate::authorize('update', $cardCollection);
 
        $validated = $request->validate([
            'name' => 'required|string|max:255',
        ]);
 
        $cardCollection->update($validated);
 
        return redirect(route('cardCollections.index'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(CardCollection $cardCollection): RedirectResponse
    {
        Gate::authorize('delete', $cardCollection);

        $cardCollection->delete();

        return redirect(route('cardCollections.index'));
    }
}