<?php

namespace App\Http\Controllers;

use App\Models\Card;
use App\Models\CardCollection;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Inertia\Inertia;
use Inertia\Response;

class CardController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        {
            $user=Auth::user();
            $userid = $user->id;
            return Inertia::render('Cards/Index', [
                'cards' => Card::with('user:id,card_front,card_back')->latest()->get(),
                'cardCollections' => CardCollection::all()->where('user_id', $userid),
            ]);
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'card_front' => 'required|string|max:255',
            'card_back' => 'required|string|max:255',
            'card_collection_id' => 'required|exists:card_collections,id',
        ]);

        $request->user()->cards()->create($validated);
    
        return redirect(route('cards.index'));
    }
    /**
     * Display the specified resource.
     */
    public function show(Card $card)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Card $card)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Card $card)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Card $card)
    {
        //
    }
}
